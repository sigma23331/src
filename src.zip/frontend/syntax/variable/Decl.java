package frontend.syntax.variable;
import frontend.syntax.BlockItem;

//声明 Decl → ConstDecl | VarDecl

public abstract class Decl extends  BlockItem{
        //继承print
}
