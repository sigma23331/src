package optimize;

import middle.component.inst.*;
import middle.component.model.BasicBlock;
import middle.component.model.Function;
import middle.component.model.Module;
import middle.component.model.Value;
import middle.component.model.User;
import middle.component.model.Use;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PhiElimination {

    public static void run(Module module) {
        for (Function func : module.getFunctions()) {
            if (func.isDeclaration()) continue;
            demotePhisToStack(func);
        }
    }

    private static void demotePhisToStack(Function func) {
        List<PhiInst> allPhis = new ArrayList<>();
        // 收集所有 Phi
        for (BasicBlock block : func.getBasicBlocks()) {
            for (Instruction inst : block.getInstructions()) {
                if (inst instanceof PhiInst) {
                    allPhis.add((PhiInst) inst);
                }
            }
        }

        if (allPhis.isEmpty()) return;

        BasicBlock entryBlock = func.getEntryBlock();
        // 找到插入 Alloca 的位置：在所有现有的 Alloca 之后，或者块的开头
        // 简单起见，我们统一插在 entryBlock 的最前面，MipsBuilder 会处理顺序

        Map<PhiInst, AllocInst> phiToAlloc = new HashMap<>();

        // ------------------------------------------------
        // 1. 为每个 Phi 创建独立的 Alloca
        // ------------------------------------------------
        int phiCounter = 0;
        for (PhiInst phi : allPhis) {
            // 给每个 Phi 一个唯一的名字，方便调试
            // 例如: phi_0.addr, phi_1.addr
            String allocName = "phi_" + (phiCounter++) + ".addr";
            AllocInst alloc = new AllocInst(allocName, phi.getType());

            entryBlock.getInstructions().add(0, alloc); // 插在最前面
            alloc.setParent(entryBlock);

            phiToAlloc.put(phi, alloc);
        }

        // ------------------------------------------------
        // 2. 处理 Incoming Values -> Store
        // ------------------------------------------------
        for (PhiInst phi : allPhis) {
            AllocInst alloc = phiToAlloc.get(phi);

            for (int i = 0; i < phi.getNumIncoming(); i++) {
                Value val = phi.getIncomingValue(i);
                BasicBlock srcBlock = phi.getIncomingBlock(i);

                // 在前驱块末尾插入 Store
                StoreInst store = new StoreInst(val, alloc);
                insertInstructionBeforeTerminator(srcBlock, store);
            }
        }

        // ------------------------------------------------
        // 3. 处理 Users -> Load
        // ------------------------------------------------
        // 策略：在 Phi 定义所在的块（即 Phi 的 Parent）的开头，
        // 插入一个 Load，并用这个 Load 替换 Phi 的所有使用。
        // 因为 Phi 的语义是：在进入该块的那一刻，值就确定了。

        for (PhiInst phi : allPhis) {
            AllocInst alloc = phiToAlloc.get(phi);
            BasicBlock phiBlock = phi.getParent();

            // 创建 Load
            LoadInst load = new LoadInst("phi_" + phiToAlloc.hashCode() + ".load", alloc);

            // 插入位置：紧接着所有 Phi 指令之后
            // 必须跳过该块开头的所有 Phi (包括当前的 phi 和其他的 phi)
            // 否则会破坏 "Phi 必须在块开头" 的结构 (虽然我们马上要删了它们，但为了逻辑清晰)
            insertAfterAllPhis(phiBlock, load);

            // 替换引用
            phi.replaceAllUsesWith(load);

            // 移除 Phi
            // 注意：因为我们是分步处理，最后统一移除比较安全
            // 这里先断开连接
            phi.removeOperands();
        }

        // 4. 统一从块中移除 Phi 指令
        for (PhiInst phi : allPhis) {
            // 已经在上面调用了 removeOperands，现在从 List 中移除
            // 如果你有 phi.remove() 且逻辑正确(检查parent)，可以直接调
            // 这里手动移除确保万无一失
            if (phi.getParent() != null) {
                phi.getParent().getInstructions().remove(phi);
                phi.setParent(null);
            }
        }
    }

    private static void insertAfterAllPhis(BasicBlock block, Instruction newInst) {
        List<Instruction> insts = block.getInstructions();
        int idx = 0;
        for (Instruction inst : insts) {
            if (inst instanceof PhiInst) {
                idx++;
            } else {
                break;
            }
        }
        // 插在 idx 处
        if (idx < insts.size()) {
            insts.add(idx, newInst);
        } else {
            insts.add(newInst);
        }
        newInst.setParent(block);
    }

    private static void insertInstructionBeforeTerminator(BasicBlock block, Instruction inst) {
        List<Instruction> insts = block.getInstructions();
        if (insts.isEmpty()) {
            block.addInstruction(inst);
            return;
        }

        Instruction last = insts.get(insts.size() - 1);
        // 使用你的终结符判断逻辑
        boolean isTerminator = last instanceof middle.component.inst.BrInst
                || last instanceof middle.component.inst.RetInst;

        if (isTerminator) {
            insts.add(insts.size() - 1, inst);
            inst.setParent(block);
        } else {
            block.addInstruction(inst);
        }
    }
}