package frontend.syntax;

public abstract class BlockItem extends SyntaxNode {
    // 继承了抽象的 print() 方法
}
