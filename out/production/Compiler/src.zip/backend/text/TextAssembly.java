package backend.text;

public interface TextAssembly {
    String toString();
}
