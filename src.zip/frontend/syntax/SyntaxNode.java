package frontend.syntax;

public abstract class SyntaxNode {
    public abstract void print();
}
