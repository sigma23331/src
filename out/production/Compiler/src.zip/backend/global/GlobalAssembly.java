package backend.global;

public interface GlobalAssembly {
    String toString();
}
