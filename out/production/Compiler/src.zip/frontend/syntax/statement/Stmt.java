package frontend.syntax.statement;

import frontend.syntax.BlockItem;

public abstract class Stmt extends BlockItem {
    // 继承了抽象的 print() 方法
}
